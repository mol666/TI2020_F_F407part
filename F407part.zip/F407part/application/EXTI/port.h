#ifndef __PORT_H
#define __PORT_H	 
#include "sys.h"  	
extern u8 enable_flag;
extern u8  function_flag;
extern u8  judge_flag;
extern u8 exti_flag;
void PORT_Init(void);
void port_detect(void);
#endif

























