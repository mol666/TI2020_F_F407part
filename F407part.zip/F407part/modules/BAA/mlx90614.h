#ifndef _MLX90614_H
#define _MLX90614_H

#include "sys.h"
#include "math.h"

/* Includes ------------------------------------------------------------------*/


#include "delay.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define ACK         0 //Ӧ��
#define        NACK 1 //��Ӧ��
#define SA                                0x00 //Slave address ����MLX90614ʱ��ַΪ0x00,���ʱ��ַĬ��Ϊ0x5a
#define RAM_ACCESS                0x00 //RAM access command RAM��ȡ����
#define EEPROM_ACCESS        0x20 //EEPROM access command EEPROM��ȡ����
#define RAM_TOBJ1                0x07 //To1 address in the eeprom Ŀ��1�¶�,��⵽�ĺ����¶� -70.01 ~ 382.19��

#define SMBUS_PORT        		 GPIOB      //PB�˿�(�˿ں������������ſ��Զ���)
#define SMBUS_SCK                GPIO_Pin_8 //PB8��SCL
#define SMBUS_SDA                GPIO_Pin_9 //PB9��SDA

#define RCC_AHB1Periph_SMBUS_PORT                RCC_AHB1Periph_GPIOB

#define SMBUS_SCK_H()            SMBUS_PORT->BSRRL = SMBUS_SCK //�øߵ�ƽ
#define SMBUS_SCK_L()            SMBUS_PORT->BSRRH = SMBUS_SCK  //�õ͵�ƽ
#define SMBUS_SDA_H()            SMBUS_PORT->BSRRL = SMBUS_SDA
#define SMBUS_SDA_L()            SMBUS_PORT->BSRRH = SMBUS_SDA

#define SMBUS_SDA_PIN()            SMBUS_PORT->IDR & SMBUS_SDA //��ȡ���ŵ�ƽ

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
//u16 SMBus_ReadTemp(void);//����
float SMBus_ReadTemp(void);
void SMBus_Init(void);
void SMBus_StartBit(void);
void SMBus_StopBit(void);
u8 SMBus_SendByte(u8 Tx_buffer);
void SMBus_SendBit(u8 bit_out);
u8 SMBus_ReceiveBit(void);
u8 SMBus_ReceiveByte(u8 ack_nack);
void SMBus_Delay(u16 time);
u16 SMBus_ReadMemory(u8 slaveAddress, u8 command);
u8 PEC_Calculation(u8 pec[]);
void SMBus_SDA_INMode(void);
void SMBus_SDA_OUTMode(void);
#endif
